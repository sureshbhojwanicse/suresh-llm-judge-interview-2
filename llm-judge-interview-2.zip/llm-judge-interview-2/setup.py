from setuptools import find_packages, setup

setup(
    name="llm_judge",
    version="0.1",
    description="Automatic evaluation package for LLMs",
    author="Amy Deng",
    author_email="amy@withmartian.com",
    packages=find_packages(),
)
